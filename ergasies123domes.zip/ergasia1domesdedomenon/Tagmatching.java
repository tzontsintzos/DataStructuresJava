
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;



public class TagMatching {
	
	public static void main(String[] args) throws FileNotFoundException {
		
		File htmlfile = new File("C:\\Users\\jtsin\\myhtmlfile.html");
		Scanner in = new Scanner(htmlfile);
		System.out.println(in.nextLine());
		//System.out.println(in.nextLine());
		
		// reading file
        int runner; // runs through each line
        int mp1 = 0; // matches the position of "<"
        int mp2 = 0; // matches the position of ">"
        String sub;
        try {
           
            String line = in.nextLine(); // reads next line
            StringStackImpl<String> Stack1 = new StringStackImpl<String>();
            while (line != null) { // while there is a next line, meaning the file has not ended
                for (runner = 0; runner < line.length(); runner++) { // loop running through each line
                    if ((line.charAt(runner)) == '<') { // if we find "<"
                        mp1 = runner;
                    }
                    if ((line.charAt(runner)) == '>') { // if we find ">"
                        mp2 = runner;

                        if (mp1 < mp2) { // means we found a tag

                            sub = line.substring(mp1 + 1, mp2); // create substring, using matching positions
                            if (ReconTag(sub)) { // opening tag
                                Stack1.push(sub); // go inside the stack
                            } else { // if is closing
                                sub = sub.substring(1); // take the index of the tag with out "/"
                                if (sub.equals(Stack1.peek()))
                                    Stack1.pop(); // if the closing tag matches the last opening tag, then pop that from
                                                  // the stack
                            }
                            mp1 = 0; // reseting mp's, for the next time we will need them
                            mp2 = 0;
                        }
                    }
                }
               // if (line != null){
                //	line = in.nextLine(); }// read next line, to continue loop
                
            }
            
            if (Stack1.isEmpty()) { // program's output, and exit
                System.out.println("This HTML file has matching tags");
            } else {
                System.out.println("This HTML file doesn't have matching tags");
            }
            
            line = null;}
            
            finally {in.close();}
            
        //} catch (IOException e) { // exception
           // System.err.println("Error opening / reading file!");
        //}
    }

    // ReconTagMethod, recognizes whether a tag is opening or closing
    public static boolean ReconTag(String subS) {
        if (subS.startsWith("/"))
            return false; // it's a closing tag
        else
            return true; // it's an opening tag
 


	}
	

}





//int testCases = Integer.parseInt(in.nextLine());

//while (testCases>0) {
	//String line = in.nextLine();
	//boolean matchfound = false;
	//Pattern pattern = Pattern.compile("<(.+)>([^<]+)<\\1>");
	//Matcher match 
//}