import java.io.PrintStream;
import java.util.NoSuchElementException;

public class StringStackImpl<T> {
    private Node<T> head = null;
    private Node<T> tail = null;
    int size1 = 0;

    public boolean isEmpty() {
        return head == null;
    }

    public void push(T item) {
        Node<T> n = new Node<>(item);

        if (isEmpty()) {
            head = n;
            tail = n;
        } else {
            n.setNext(head);
            head = n;
        }
        size1++;
    }

    public T pop() throws NoSuchElementException {
        if (isEmpty())
            throw new NoSuchElementException();
        T top = head.getData();

        if (head == tail) {
            head = tail = null;
        } else {
            head = head.getNext();
        }
        size1--;
        return top;

    }

    public T peek() throws NoSuchElementException {
        if (isEmpty())
            throw new NoSuchElementException();
        T top = head.getData();
        return top;
    }

    public void printStack(PrintStream stream) {
        int k = size1;
        if (isEmpty()) {
            System.out.println("is empty");
        } else {
            while (k > 0) {
                System.out.println(head.getData());
                head = head.getNext();
                k--;
            }
        }
    }

    public int size() {
        return size1;
    }
}