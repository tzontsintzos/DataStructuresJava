import java.util.NoSuchElementException;

public class Main {
    public static void main(String[] args) {

        StringStackImpl<Integer> stoiva = new StringStackImpl<>();
		try {
        	stoiva.push(1);
        	stoiva.push(2);
        	stoiva.push(3);
			System.out.println(stoiva.isEmpty());
			System.out.println(stoiva.size());
			stoiva.pop();
			stoiva.pop();
			stoiva.pop();
			stoiva.pop();

       	    stoiva.printStack(System.out);
		}

		catch (NoSuchElementException exep){
			System.out.println("Tried to remove from an empty stack!");
		}


		IntQueueImpl<String> oura = new IntQueueImpl<>();

		try{
			oura.put("b");
			oura.put("v");
			oura.get();
			oura.put("x");
			oura.peek();
			oura.peek();
			System.out.println(oura.isEmpty());
			oura.put("k");
			oura.put("o");
			System.out.println(oura.size());
			oura.get();
			oura.get();
			oura.get();
			oura.get();
			oura.get();
			oura.isEmpty();
			oura.printQueue(System.out); 
		}

		catch (NoSuchElementException exep){
			System.out.println("Tried to remove from an empty queue!");
		}
		

    }

}
