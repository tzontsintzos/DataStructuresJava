import java.io.PrintStream;
import java.util.NoSuchElementException;

public class IntQueueImpl<T> {
    private Node<T> head = null;
    private Node<T> tail = null;
    int size1 = 0;

    public boolean isEmpty() {
        return head == null;
    }

    public void put(T item) {
        Node<T> n = new Node<>(item);

        if (isEmpty()) {
            head = n;
            tail = n;
        } else {
            tail.setNext(n);
            tail = n;
        }
        size1++;
    }

    public T get() throws NoSuchElementException {
        if (isEmpty())
            throw new NoSuchElementException();
        T oldest = head.getData();

        if (head == tail) {
            head = tail = null;
        } else {
            head = head.getNext();
        }
        size1--;
        return oldest;
    }

    public T peek() throws NoSuchElementException {
        if (isEmpty())
            throw new NoSuchElementException();
        T oldest = head.getData();
        return oldest;
    }

    public void printQueue(PrintStream stream) {
        int k = size1;
        if (isEmpty()) {
            System.out.println("is empty");
        } else {
            while (k > 0) {
                System.out.println(head.getData());
                head = head.getNext();
                k--;
            }
        }
    }

    public int size() {
        return size1;
    }
}
