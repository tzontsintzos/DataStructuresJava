
public class StrNode {
	
	
		
	    protected String item;
	    protected StrNode next = null;

	    
	    

	    

		public StrNode(String item) {
			this.item = item;
		}

		/**
	     * Returns this node's data
	     *
	     * @return the reference to node's data
	     */
	    public String getItem() {
	        // return data stored in this node
	        return item;
	    }

	    /**
	     * Get reference to next node
	     *
	     * @return the next node
	     */
	    public StrNode getNext() {
	        // get next node
	        return next;
	    }


	    /**
	     * Set reference to next node
	     *
	     * @param next reference
	     */
	    public void setNext(StrNode next) {
	        this.next = next;
	    }
	}



