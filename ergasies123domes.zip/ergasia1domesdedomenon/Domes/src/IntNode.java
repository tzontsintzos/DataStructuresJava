

public class IntNode {
	
		
		protected int item;
		protected IntNode next;
	
		public IntNode(int item) {
			this.item = item;
		}

	
	

	    
	    public int getItem() {
	        // return data stored in this node
	        return item;
	    }

	    /**
	     * Get reference to next node
	     *
	     * @return the next node
	     */
	    public IntNode getNext() {
	        // get next node
	        return next;
	    }


	    /**
	     * Set reference to next node
	     *
	     * @param next reference
	     */
	    public void setNext(IntNode next) {
	        this.next = next;
	    }
	


}
