import java.io.PrintStream;
import java.util.NoSuchElementException;

public class StringStackImpl implements StringStack {
	
	private StrNode head ;
	private int Size;
	
	
	
	public StringStackImpl() {
		Size=0;
		head = null;
		
	}
	
	public boolean isEmpty() {
		return head == null;
	}
	
	public void push(String item) {
		StrNode prevHead = head;
		head = new StrNode(item);
		head.next=prevHead;
		Size++;
        }
		
        
        

	
	public String pop() throws NoSuchElementException {
		
		if (isEmpty())
			throw new NoSuchElementException();
		String item = head.item;
		head = head.next;
		Size--;
		return item;
	}
	
	public String peek() throws NoSuchElementException {
		if (isEmpty())
			throw new NoSuchElementException();
		return head.getItem();
	}
		
	public void printStack(PrintStream stream) {
		StrNode x = head;	
		if (x != null) {
			while (x != null) {
				stream.println(x.getItem());
				x = x.getNext();

			}
		} else {
			stream.println("list null");
		}
		
	}
	
	public int size() {
		if (isEmpty())	
			return 0;
		else
			return Size;
	}
	
}
