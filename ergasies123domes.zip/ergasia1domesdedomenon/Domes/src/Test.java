import java.util.NoSuchElementException;
import java.io.PrintStream;

public class Test {
	
		public static void main(String[] args) {
	        // Create an empty list
	        IntQueueImpl list = new IntQueueImpl();
	        StringStackImpl list2 = new StringStackImpl();
	
	        try {
	
	            // Print empty list
	        	PrintStream stream = new PrintStream(System.out);
	        	list.printQueue(stream);
	        	list2.printStack(stream);
	        	
	        	
	            // Add two elements at front
	            list.put(1);
	            list2.push("ena");
	            stream.println("element 1 added.");
	            stream.println("new lists: ");
	            list.printQueue(stream);
	            list2.printStack(stream);
	            
	            list.put(2);
	            list2.push("dyo");
	            stream.println("\nelement 2 added.");
	            stream.println("new lists: ");
	            list.printQueue(stream);
	            list2.printStack(stream);
	            

	            // Remove from front
	            int removed = list.get();
	            String removed2 = list2.pop();
	            System.out.println("\nHead removed ("+removed+", "+removed2+").\n");
	            stream.println("new lists: ");
	            list.printQueue(stream);
	            list.printQueue(stream);
	            
	            
	            int k = list.peek();
	            String k2 = list2.peek();
	            System.out.println("\nnew heads: " + k +" " +k2);

	            stream.print("lists sizes: "+list.size()+" "+list2.size());

	        	
	            
	            }
            catch ( NoSuchElementException ex) {
                System.out.println("Tried to remove from an empty stack!");}
	        
	} 
}