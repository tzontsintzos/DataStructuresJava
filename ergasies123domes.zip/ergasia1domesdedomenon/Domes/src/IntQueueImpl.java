import java.io.PrintStream;
import java.util.NoSuchElementException;

public class IntQueueImpl implements IntQueue{
	
	private IntNode head;
    private IntNode tail;
	private int Size;
	public IntQueueImpl()
    {
		head=null;
		tail=null;
        Size=0;
    }
	
	public boolean isEmpty() {
		return head == null;
	}
	
	
	public void put(int item) {
		IntNode temp = new IntNode(item);
		if (isEmpty()) {
			head = temp;
			tail = head;
		} else {
			temp.setNext(head);
			head = temp;
		}
		Size++;
			
	}

	
	public int get() throws NoSuchElementException {
		
		if (isEmpty())
			throw new NoSuchElementException();
		
		int item = head.getItem();
		
		if (head == tail)
            head = tail = null;
        else
            head = head.getNext();
		
		Size--;
		return item;
	}

	
	
	public int peek() throws NoSuchElementException {
		if (isEmpty())
			throw new NoSuchElementException();
		return head.getItem();
	}


	
	public void printQueue(PrintStream stream) {
		IntNode in = head;
		if (in != null) {
			while (in != null) {
				stream.println(in.getItem());
				in = in.getNext();
			}
		}
		else {
			stream.println("list empty\n");
		}
		
	}

	
	public int size() {
		return Size;
	}
	
}
