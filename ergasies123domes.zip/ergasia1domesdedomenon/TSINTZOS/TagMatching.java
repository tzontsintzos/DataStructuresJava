import java.io.*;


public class TagMatching {
	
	
	public static void main(String[] args) {
		File arxeio = null;
		try {
		 	
			System.out.println(args[0]);
            arxeio = new File(args[0]);
		}catch (NullPointerException eksairesh){
			System.out.println("The file was not found");
		}
		
		int i; 
        int ot=0; //for "<"  
        int ct=0; //for ">"
        String newS;
		
		try {
			FileReader fr=new FileReader(arxeio);
			BufferedReader br=new BufferedReader(fr);
			     
			String line; 
			StringStackImpl UnmatchedStack = new StringStackImpl();
			
			while((line=br.readLine())!=null) {
				for (i=0; i<line.length() ;i++) {
					
					if( (line.charAt(i))=='<') { // finds position of "<"
                        ot= i;
                    }
					if ((line.charAt(i))=='>') { // finds position of ">"
						ct = i;
						
						if (ot<ct) {  
							
							newS = line.substring(ot+1 ,ct); //removes "<" and ">"
							if(finder(newS)) {
								
								UnmatchedStack.push(newS);} //add newS to stack if it doesn't have "/"
							
							else {
								newS=newS.substring(1);    //remove "/" from newS
								if (newS.equals(UnmatchedStack.peek())) { 
									UnmatchedStack.pop();}
								else {
									newS = newS.substring(0) +  "/" + newS.substring(0);}  //add again "/" 
								
							}
							
						}
						
					}
					
				}
								line=br.readLine();	
			}
			
			PrintStream stream = new PrintStream(System.out);
			UnmatchedStack.printStack(stream);
			
			if (UnmatchedStack.size() == 1 || UnmatchedStack.isEmpty()) { //size = 1 bc <!DOCTYPE html> exists in every html file and it doesn't have a closing tag || empty file
				System.out.println("This HTML file has matching tags!");
			}else {
				System.out.println("This HTML file has no matching tags!");
			}
			
			
			br.close();
		}catch (IOException k) {
			System.out.println("Error loading file");
		}
		
		
		
	}
	
	
	public static boolean finder(String s) {
		if (s.startsWith("/"))return false;
		else {
		return true;}
	}
	
	
	
}