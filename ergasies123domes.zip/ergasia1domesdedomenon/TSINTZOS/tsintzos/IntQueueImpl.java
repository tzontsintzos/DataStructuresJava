import java.io.PrintStream;
import java.util.NoSuchElementException;

class IntQueueImpl implements IntQueue {
    private Node2 head, tail;
    private int Size;

    public class Node2 {
        int item;
        Node2 next;

        Node2(int item) {
            this.item = item;
            next = null;

        public int getItem() {
            // return data stored in this node
            return item;
        }

        /**
         * Get reference to next node
         *
         * @return the next node
         */
        public IntNode getNext() {
            // get next node
            return next;
        }

        /**
         * Set reference to next node
         *
         * @param next reference
         */
        public void setNext(IntNode next) {
            this.next = next;
        }
    }

    }}

    public IntQueueImpl() {
        head = null;
        tail = null;
        Size = 0;

    }

    public boolean isEmpty() {
        return (head == null);
    }

    public void put(int item) {
        Node2 t = tail;
        tail = new Node2(item);
        if (isEmpty())
            head = tail;
        else
            t.next = tail;

        Size++;
    }

    public int get() throws NoSuchElementException {

        if (isEmpty())
            throw new NoSuchElementException();

        int v = head.item;
        Node2 t = head.next;
        head = t;
        Size--;
        return v;

    }

    public int peek() throws NoSuchElementException;

    {
        if (isEmpty())
            throw new NoSuchElementException();
        return head.item;
    }

    public void printQueue(PrintStream stream);

    {

    }

    public int size() {
        return Size;
    }

}
