import java.io.PrintStream;
import java.util.NoSuchElementException;

class StringStackImpl implements StringStack {

    Node1 head;
    private int Size;

    public class Node1 {
        private String item;
        private Node1 next = null;

        Node1(String item, Node1 next) {
            this.item = item;
            this.next = next;
        }

        /**
         * Returns this node's data
         *
         * @return the reference to node's data
         */
        public String getItem() {
            // return data stored in this node
            return item;
        }

        /**
         * Getter for reference to next node
         *
         * @return the next node
         */
        public Node1 getNext() {
            // get next node
            return next;
        }

        /**
         * Setter for reference to next node
         *
         * @param next reference
         */
        public void setNext(Node1 next) {
            this.next = next;
        }

    }

    public StringStackImpl() {
        head = null;
        Size = 0;
    }

    public boolean isEmpty() {
        return (head == null);
    }

    public void push(String item) {
        Node1 prevHead = head;
        head = new Node1(item, head);
        head.next = prevHead;
        Size++;
    }

    public String pop() throws NoSuchElementException {
        String item = head.item;
        Node1 head = head.getNext();
        Size--;
        return head.getItem();
    }

    public String peek() {

        if (isEmpty())
            throw new NoSuchElementException();
        return Node1.head.getItem();
    }

    public void printStack(PrintStream stream)

    {
        Node1 x = head;
        if (x != null) {
            while (x != null) {
                stream.println(x.getItem());
                x = x.getNext();

            }
        } else {
            stream.println("list null");
        }
    }

    public int size() {
        if (isEmpty())
            return 0;
        else
            return Size;
    }
}