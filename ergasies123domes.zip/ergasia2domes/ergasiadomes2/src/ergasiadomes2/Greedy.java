package ergasiadomes2;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Greedy {

    public static void main(String[] args) {
        MaxPQ pq= new MaxPQ();
        
        BufferedReader bf = null;
        try {

            String line;

            bf = new BufferedReader(new FileReader(args[0]));
            int lineNum = 2;
            
                int processors = Integer.parseInt(bf.readLine());
                int tasks = Integer.parseInt(bf.readLine());
                
                Task[] taskarray = new Task[tasks];
                int k = 0;
                
                
            while ((line = bf.readLine()) != null) {
                
                lineNum += 1;
                
                
                if (lineNum > 2 && (lineNum-2) <= tasks) {
                    int flag = 0;
                    String num1 = "", num2 = "";
                    for (int j = 0; j < line.length(); j++) {
                        if (Character.isDigit(line.charAt(j))) {
                            if (flag == 0) {
                                num1 += String.valueOf(line.charAt(j));
                            }
                            if (flag == 1) {
                                num2 += String.valueOf(line.charAt(j));
                            }
                        } else {
                            flag = 1;
                        }
                    }
                    int taskId = Integer.parseInt(num1);
                    int taskTime = Integer.parseInt(num2);
                    Task task = new Task(taskId, taskTime);
                    
                    taskarray[k]=task;
                    k++;

                }
                

            }
            
            int a = 0;
            int id = 1;
            int ntask = tasks;
            int nprocessors = processors;
            while (nprocessors != 0) {
                    List lista = new List();
                    Task task = taskarray[a];
                    lista.insertAtBack(task);
                    a++;
                    Processor pro = new Processor(id,lista);
                    pq.insert(pro);
                    id++;
                    ntask--;
                    nprocessors--;
            }
            while (ntask > 0) {
                Task task = taskarray[a];
                Processor first = pq.getmax();
                first.addtask(task);
                pq.insert(first);
                a++;
                ntask--;
                
            }
            int max = pq.max().getActiveTime();
            
            for(int i=1; i<=processors; i++) {
                
                if (tasks < 50) {
                System.out.println("id "+pq.max().getId()+","+"load="+pq.max().getActiveTime()+": "+pq.max().getList());
                }
                if (pq.max().getActiveTime() > max) {
                    max = pq.max().getActiveTime();
                }
                pq.getmax();
            }
            System.out.println("Makespan = "+ max);
            
        } catch (IOException e) {

            System.out.println("Error loading file");

        } finally {

            try {
                if (bf != null)
                    bf.close();
            } catch (IOException ex) {
                System.out.println("Error");
            }
        }

    }

}