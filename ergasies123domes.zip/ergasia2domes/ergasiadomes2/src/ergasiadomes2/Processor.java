package ergasiadomes2;

import ergasiadomes2.List.Node;

public class Processor implements Comparable<Processor>
{

	private int id;
	private int activetime;
	
	List<Task> processedTasks = new List<>();
	
	public Processor(int id,List processedTasks)
	{
		this.processedTasks = processedTasks;
		this.id = id;
	}

    public int getId() {
        return id;
    }
    
    public void addtask(Task task)
    {
    	processedTasks.insertAtBack(task);
    }
    
	public List getList() {
		
		return processedTasks;
	}
    
	public int getActiveTime()
	{
		
		if (processedTasks.isEmpty() ) {return 0;}
		
		else 
		{
			
			int sum = 0;
																	
			
			Node current = processedTasks.getHead();	
	       
	        while (current != null) {
	         
	        	sum += ((Task) current.data).getTime();
	        	
	            current = current.next;
																					
			}
			return sum ;
		}	

	}
	
	@Override
	
		public int compareTo(Processor A) 
		{
		    /**
		     * Compares its two arguments for order.
		     *
		     * @param A
		     * @param B
		     * @return a negative integer, zero, or a positive integer as the !first! argument
		     * is less than, equal to, or greater !than the second!.
		     */
			
		if (this.getActiveTime() != A.getActiveTime() )
				return  A.getActiveTime() - this.getActiveTime();
			
			else 
			{
				if ( this.getId() < A.getId() )
					return this.getActiveTime() - A.getActiveTime();
				else
					return this.getActiveTime() - A.getActiveTime();
			}
		
		
		}
	
	

    
}