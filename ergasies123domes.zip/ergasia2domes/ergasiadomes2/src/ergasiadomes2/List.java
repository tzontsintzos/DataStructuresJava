package ergasiadomes2;

/**
 * Single-link List. Uses {@link Node} for list nodes.
 */
public class List<T> implements ListInterface<T> {
	
	/**
	 * ListNode represents a list node
	 * Each node contains a generic type T as data and a reference to the next node in the list.
	 */
	public class Node<T> {
	    protected T data;
	    protected Node next = null;

	    /**
	     * Constructor. Sets data
	     *
	     * @param data the data stored
	     * @return
	     */
	    Node(T data) {
	        this.data = data;
	    }

	    /**
	     * Returns this node's data
	     *
	     * @return the reference to node's data
	     */
	    public T getData() {
	        // return data stored in this node
	        return data;
	    }

	    /**
	     * Get reference to next node
	     *
	     * @return the next node
	     */
	    public Node<T> getNext() {
	        // get next node
	        return next;
	    }

	    /**
	     * Set reference to next node
	     *
	     * @param next reference
	     */
	    public void setNext(Node<T> next) {
	        this.next = next;
	    }
	}

	int size=0;
    private Node<T> head = null;
    private Node<T> tail = null;

    /**
     * Default constructor
     */
    public List() {
    }

    /**
     * Determine whether list is empty
     *
     * @return true if list is empty
     */
    @Override
    public boolean isEmpty() {
        return head == null;
    }

    /**
     * Inserts the data at the front of the list
     *
     * @param data the inserted data
     */
    @Override
    public void insertAtFront(T data) {
        Node<T> n = new Node<>(data);

        if (isEmpty()) {
            head = n;
            tail = n;
        } else {
            n.setNext(head);
            head = n;
            size ++;
        }
    }

    /**
     * Inserts the data at the end of the list
     *
     * @param data the inserted item
     */
    @Override
    public void insertAtBack(T data) {
        Node<T> n = new Node<>(data);

        if (isEmpty()) {
            head = n;
            tail = n;
        } else {
            tail.setNext(n);
            tail = n;
            size ++;
        }
    }

    /**
     * Returns and removes the data from the list head
     *
     * @return the data contained in the list head
     * @throws EmptyListException if the list is empty
     */
    @Override
    public T removeFromFront() throws EmptyListException {
        if (isEmpty())
            throw new EmptyListException();

        T data = head.getData();
        
        if (head == tail) {
        	size = 0;
            head = tail = null;}
        else {
            head = head.getNext();
        	size -- ;}
        return data;
    }

    /**
     * Returns and removes the data from the list tail
     *
     * @return the data contained in the list tail
     * @throws EmptyListException if the list is empty
     */
    @Override
    public T removeFromBack() throws EmptyListException {
        if (isEmpty())
            throw new EmptyListException();

        T data = tail.getData();

        if (head == tail)
            head = tail = null;
        else {
            Node<T> iterator = head;
            while (iterator.getNext() != tail)
                iterator = iterator.getNext();

            iterator.setNext(null);
            tail = iterator;
        }

        return data;
    }

    /**
     * Returns list as String
     */
    @Override
    public String toString() {
        if (isEmpty()) {
            return "List is empty :(";
        }

        Node current = head;

        StringBuilder ret = new StringBuilder();

        // while not at end of list, output current node's data
       

        while (current != null) {
            ret.append(current.data.toString());

            if (current.getNext() != null)
                ret.append(" ");

            current = current.next;
        }

        

        return ret.toString();
    }
    
    public Node<T> getHead(){
    	return head;
    }
    
    public Node<T> getTail(){
    	return tail;
    }
    
    public int size() {
    	return size;
    }
}

