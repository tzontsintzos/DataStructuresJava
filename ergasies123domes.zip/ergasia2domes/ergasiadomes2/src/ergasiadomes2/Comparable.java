package ergasiadomes2;

public interface Comparable<Processor> {

	int compareTo(Processor A);

}
